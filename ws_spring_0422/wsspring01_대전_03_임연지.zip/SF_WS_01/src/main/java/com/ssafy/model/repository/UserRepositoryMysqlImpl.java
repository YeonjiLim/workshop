/**
 *
 */
package com.ssafy.model.repository;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.UserInfo;

/**
 * @author itsme
 * @Date : 2019. 4. 14.
 */
@Repository
public class UserRepositoryMysqlImpl implements UserRepository {
	private static final Logger logger = LoggerFactory.getLogger(UserRepositoryMysqlImpl.class);
	@Override
	public List<UserInfo> selectAllUsers() {
		logger.trace("selectAllUsers");
		return null;
	}

	@Override
	public UserInfo select(String id) {
		logger.trace("select: id: {}", id);
		return null;
	}

	@Override
	public int insert(UserInfo info) {
		logger.trace("insert: info: {}", info);
		return 0;
	}

	@Override
	public int update(UserInfo info) {
		logger.trace("update: info: {}", info);
		return 0;
	}

	@Override
	public int delete(String userId) {
		logger.trace("delete: userId: {}", userId);
		return 0;
	}
}
