package com.ssafy.test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ssafy.config.ApplicationConfig;
import com.ssafy.exception.TimeoutException;
import com.ssafy.model.dto.UserInfo;
import com.ssafy.model.repository.UserRepository;
import com.ssafy.model.service.UserService;

// TODO: 테스트 환경을 구축한다.
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = ApplicationConfig.class)
public class BeanTest {

	// TODO: ApplicationContext를 주입받는다.
	@Autowired
	ApplicationContext ctx;

	// TODO: repoJDBC이름으로 UserRepository 타입 빈이 잘 등록되어있는지 확인한다.
	@Test
	public void testRepositoryJDBC() {
		UserRepository repo1 = ctx.getBean("userRepositoryJDBCImpl", UserRepository.class);
		assertThat(repo1, is(notNullValue()));
	}

	// TODO: repoMySql 이름으로 UserRepository 타입 빈이 잘 등록되어있는지 확인한다.
	@Test
	public void testRepositoryMySQL() {
		UserRepository repo1 = ctx.getBean("userRepositoryMysqlImpl", UserRepository.class);
		assertThat(repo1, is(notNullValue()));
	}

	// TODO: UserService 타입의 빈이 잘 등록되어있는지 확인하고 UserService에서 얻은 Repository가 repoMysql이름으로 등록된 UserRepository 타입 빈과 동일한지 확인한다.
	@Test
	public void testService() {
		UserService service = ctx.getBean(UserService.class);
		assertThat(service, is(notNullValue()));
		UserRepository repo1 = ctx.getBean("userRepositoryMysqlImpl", UserRepository.class);
		assertThat(repo1, is(service.getUserRepo()));
	}

	@Test(expected = TimeoutException.class)
	public void testTimeoutMethod() {
		UserService service = ctx.getBean(UserService.class);
		UserInfo info = new UserInfo("hong", "홍길동", "1234");
		service.joinDayTime(info);
	}
}
